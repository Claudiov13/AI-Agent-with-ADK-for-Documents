from google.adk import Agent
from google.adk.tools import VertexAiSearchTool


search_tool = VertexAiSearchTool(data_store_id="projects/414873609601/locations/global/collections/default_collection/dataStores/acessafacil-search_1755114140363")

# Cria o agente principal
root_agent = Agent(
    model="gemini-2.5-pro",
    name="Acessafácil",
    instruction="""
    Para qualquer pergunta sempre use a tool search_tool
    """,
    tools=[search_tool]
)
 


